import 'package:flutter/material.dart';
import 'widgets/navigation_bar.dart';
import 'widgets/status_bar.dart';
import 'widgets/plant_health_card.dart';
import 'widgets/sensor_cards.dart';
import 'widgets/alerts_card.dart';
import 'widgets/live_stream_widget.dart';
import 'dart:async';

class HomeScreen extends StatefulWidget {
  final VoidCallback toggleTheme;
  const HomeScreen({Key? key, required this.toggleTheme}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentNavIndex = 0;
  DateTime _lastUpdate = DateTime.now();
  final bool _isOnline = true;
  final int _healthPercentage = 89;
  final String _lastImageTime = "Today 14:35";
  final List<Map<String, dynamic>> _alerts = [
    {
      'type': 'info',
      'message': 'Ideal temperature for photosynthesis',
      'time': '',
    },
    {'type': 'warning', 'message': 'Soil moisture is decreasing', 'time': ''},
  ];

  late Timer _refreshTimer;

  @override
  void initState() {
    super.initState();
    _refreshTimer = Timer.periodic(const Duration(minutes: 1), (timer) {
      _refreshData();
    });
  }

  @override
  void dispose() {
    _refreshTimer.cancel();
    super.dispose();
  }

  void _refreshData() {
    setState(() {
      _lastUpdate = DateTime.now();
    });
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    bool isDesktop = screenWidth > 1000;

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Agricultural Tracking Robot",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        automaticallyImplyLeading: false,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF4CAF50), Color(0xFF2E7D32)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications, color: Colors.white),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.brightness_6, color: Colors.white),
            onPressed: widget.toggleTheme,
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          _refreshData();
          return Future.delayed(const Duration(milliseconds: 500));
        },
        child: LayoutBuilder(
          builder: (context, constraints) {
            if (isDesktop) {
              return Row(
                children: [
                  // Sol: Canlı Akış (%60)
                  Expanded(
                    flex: 6,
                    child: Padding(
                      padding: const EdgeInsets.all(24.0),
                      child: SizedBox(
                        height: constraints.maxHeight,
                        child: SingleChildScrollView(
                          child: ConstrainedBox(
                            constraints: BoxConstraints(
                              minHeight: constraints.maxHeight,
                              maxHeight: constraints.maxHeight,
                            ),
                            child: Center(
                              child: // Desktop görünümünde LiveStreamWidget'ın bulunduğu kısım
                                  Expanded(
                                flex: 6,
                                child: Padding(
                                  padding: const EdgeInsets.all(24.0),
                                  child: SingleChildScrollView(
                                    child: LiveStreamWidget(
                                      initialStreamUrl:
                                          'http://192.168.7.252:8000/video_feed',
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  // Sağ: Diğer Kartlar (%40)
                  Expanded(
                    flex: 4,
                    child: Padding(
                      padding: const EdgeInsets.only(
                        top: 24.0,
                        bottom: 24.0,
                        right: 24.0,
                        left: 0.0,
                      ),
                      child: SizedBox(
                        height: constraints.maxHeight,
                        child: SingleChildScrollView(
                          child: Column(
                            children: [
                              StatusBar(
                                lastUpdate: _lastUpdate,
                                isOnline: _isOnline,
                              ),
                              const SizedBox(height: 16),
                              PlantHealthCard(
                                healthPercentage: _healthPercentage,
                                lastImageTime: _lastImageTime,
                              ),
                              const SizedBox(height: 16),
                              SensorCards(),
                              const SizedBox(height: 16),
                              AlertsCard(alerts: _alerts),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              );
            } else {
              // Mobil ve tablet: tek kolon
              return SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      LiveStreamWidget(
                        initialStreamUrl:
                            'http://192.168.7.252:8000/video_feed',
                      ),
                      const SizedBox(height: 12),
                      StatusBar(
                        lastUpdate: _lastUpdate,
                        isOnline: _isOnline,
                      ),
                      const SizedBox(height: 8),
                      PlantHealthCard(
                        healthPercentage: _healthPercentage,
                        lastImageTime: _lastImageTime,
                      ),
                      const SizedBox(height: 12),
                      SensorCards(),
                      const SizedBox(height: 12),
                      AlertsCard(alerts: _alerts),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              );
            }
          },
        ),
      ),
      bottomNavigationBar: CustomBottomNavigationBar(
        currentIndex: _currentNavIndex,
        onTap: (index) {
          setState(() {
            _currentNavIndex = index;
          });
        },
      ),
    );
  }
}
