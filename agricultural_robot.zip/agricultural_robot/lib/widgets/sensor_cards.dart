import 'dart:async';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class SensorCards extends StatefulWidget {
  const SensorCards({Key? key}) : super(key: key);

  @override
  State<SensorCards> createState() => _SensorCardsState();
}

class _SensorCardsState extends State<SensorCards> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Sensor değerleri için state değişkenleri
  double _soilMoisture = 0.0;
  double _temperature = 0.0;
  double _humidity = 0.0;
  DateTime _lastUpdate = DateTime.now();
  String _irrigationStatus = "Inactive";
  String _lastIrrigation = "N/A";

  // Timer için değişken
  Timer? _updateTimer;

  @override
  void initState() {
    super.initState();
    _loadSensorData(); // Sayfa yüklenir yüklenmez verileri çek
    _updateTimer = Timer.periodic(const Duration(seconds: 30), (timer) {
      _loadSensorData();
    });
  }

  @override
  void dispose() {
    _updateTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadSensorData() async {
    try {
      // Toprak nemi verilerini al
      final soilSnapshot = await _firestore
          .collection('sensor')
          .doc('soil')
          .collection('soil_logs')
          .orderBy('timestamp', descending: true)
          .limit(1)
          .get();

      // Sıcaklık ve nem verilerini al
      final tempSnapshot = await _firestore
          .collection('sensor')
          .doc('temperature')
          .collection('temperature_logs')
          .orderBy('timestamp', descending: true)
          .limit(1)
          .get();

      double soilMoisture = _soilMoisture;
      double temperature = _temperature;
      double humidity = _humidity;
      DateTime lastUpdate = _lastUpdate;

      if (soilSnapshot.docs.isNotEmpty) {
        final soilData = soilSnapshot.docs.first.data();
        soilMoisture = (soilData['percentage'] as num).toDouble();
        lastUpdate = (soilData['timestamp'] as Timestamp).toDate();
      }
      debugPrint("${tempSnapshot.docs.first.data()}");
      if (true) {
        final tempData = tempSnapshot.docs.first.data();

        debugPrint("tempData ${tempData['humidity']}");
        temperature = (tempData['temperature'] as num).toDouble();
        humidity = (tempData['humidity'] as num).toDouble();
      }

      // Motor durumunu kontrol et
      final motorSnapshot =
          await _firestore.collection('motor').doc('su').get();
      String irrigationStatus = _irrigationStatus;
      if (motorSnapshot.exists) {
        irrigationStatus =
            motorSnapshot.data()?['calis'] == true ? "Active" : "Inactive";
      }

      // Son sulama zamanını al
      final lastIrrigationSnapshot = await _firestore
          .collection('motor')
          .doc('su')
          .collection('irrigation_logs')
          .orderBy('timestamp', descending: true)
          .limit(1)
          .get();

      String lastIrrigation = _lastIrrigation;
      if (lastIrrigationSnapshot.docs.isNotEmpty) {
        final lastIrrigationData = lastIrrigationSnapshot.docs.first.data();
        final lastIrrigationTime =
            (lastIrrigationData['timestamp'] as Timestamp).toDate();
        lastIrrigation = _formatDateTime(lastIrrigationTime);
      }

      // State'i güncelle
      setState(() {
        _soilMoisture = soilMoisture;
        _temperature = temperature;
        _humidity = humidity;
        _lastUpdate = lastUpdate;
        _irrigationStatus = irrigationStatus;
        _lastIrrigation = lastIrrigation;
      });
    } catch (e) {
      debugPrint('Veri yükleme hatası: $e');
    }
  }

  Future<void> _toggleIrrigation() async {
    try {
      final motorRef = _firestore.collection('motor').doc('su');
      final motorDoc = await motorRef.get();

      if (motorDoc.exists) {
        final currentState = motorDoc.data()?['calis'] ?? false;
        await motorRef.update({'calis': !currentState});

        // Sulama başlatıldığında log ekle
        if (!currentState) {
          await motorRef.collection('irrigation_logs').add(
              {'timestamp': FieldValue.serverTimestamp(), 'action': 'start'});
        }

        _loadSensorData(); // Verileri yenile
      }
    } catch (e) {
      debugPrint('Sulama kontrolü hatası: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Sulama kontrolü başarısız: $e')),
        );
      }
    }
  }

  String _formatDateTime(DateTime dateTime) {
    return "${dateTime.day}/${dateTime.month} ${dateTime.hour}:${dateTime.minute.toString().padLeft(2, '0')}";
  }

  String _formatTime(DateTime dateTime) {
    return "${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}";
  }

  Color _getMoistureColor(double percentage) {
    if (percentage < 30) return Colors.red; // Very dry
    if (percentage < 50) return Colors.orange; // Dry
    if (percentage < 70) return Colors.green; // Ideal
    if (percentage < 85) return Colors.lightBlue; // Moist
    return Colors.blue; // Very moist
  }

  Color _getTemperatureColor(double temp) {
    if (temp < 15) return Colors.blue; // Cold
    if (temp < 22) return Colors.green; // Ideal
    if (temp < 28) return Colors.orange; // Hot
    return Colors.red; // Very hot
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 180,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 8.0),
        children: [
          _buildSoilMoistureCard(),
          _buildTemperatureHumidityCard(),
          _buildIrrigationCard(),
        ],
      ),
    );
  }

  Widget _buildSensorCard({
    required IconData icon,
    required String title,
    required String value,
    required Color color,
    required Widget child,
    required String footer,
    Widget? action,
  }) {
    return Container(
      width: 160,
      margin: const EdgeInsets.symmetric(horizontal: 4.0),
      child: Card(
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.0),
        ),
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            children: [
              Row(
                children: [
                  Icon(icon, color: color, size: 16),
                  const SizedBox(width: 4),
                  Text(
                    title,
                    style: TextStyle(fontWeight: FontWeight.w500, color: color),
                  ),
                ],
              ),
              const Spacer(),
              child,
              const Spacer(),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Flexible(
                    child: Text(
                      footer,
                      style: const TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                  ),
                  if (action != null) action,
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSoilMoistureCard() {
    return _buildSensorCard(
      icon: Icons.water_drop,
      title: "Soil Moisture",
      value: "${_soilMoisture.toStringAsFixed(1)}%",
      color: _getMoistureColor(_soilMoisture),
      child: SizedBox(
        width: 80,
        height: 80,
        child: Stack(
          alignment: Alignment.center,
          children: [
            SizedBox(
              width: 80,
              height: 80,
              child: CircularProgressIndicator(
                value: _soilMoisture / 100,
                strokeWidth: 8,
                backgroundColor: Colors.grey[300],
                valueColor: AlwaysStoppedAnimation<Color>(
                  _getMoistureColor(_soilMoisture),
                ),
              ),
            ),
            Text(
              "${_soilMoisture.toStringAsFixed(1)}%",
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
      footer: "Last Updated: ${_formatTime(_lastUpdate)}",
    );
  }

  Widget _buildTemperatureHumidityCard() {
    return _buildSensorCard(
      icon: Icons.thermostat,
      title: "Air Conditions",
      value: "${_temperature.toStringAsFixed(1)}°C",
      color: _getTemperatureColor(_temperature),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.thermostat, size: 20),
              const SizedBox(width: 4),
              Text(
                "${_temperature.toStringAsFixed(1)}°C",
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.water_drop_outlined, size: 20),
              const SizedBox(width: 4),
              Text(
                "${_humidity.toStringAsFixed(1)}%",
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ],
      ),
      footer: "DHT11 Sensor",
    );
  }

  Widget _buildIrrigationCard() {
    return _buildSensorCard(
      icon: Icons.add,
      title: "Irrigation",
      value: _irrigationStatus,
      color: _irrigationStatus == "Active" ? Colors.blue : Colors.grey,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            _irrigationStatus == "Active"
                ? Icons.water
                : Icons.water_drop_outlined,
            size: 40,
            color: _irrigationStatus == "Active" ? Colors.blue : Colors.grey,
          ),
          const SizedBox(height: 8),
          Text(
            _irrigationStatus,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: _irrigationStatus == "Active" ? Colors.blue : Colors.grey,
            ),
          ),
        ],
      ),
      footer: "Last irrigation: $_lastIrrigation",
      action: FloatingActionButton.small(
        onPressed: _toggleIrrigation,
        backgroundColor: Colors.blue,
        child: Icon(
          _irrigationStatus == "Active" ? Icons.stop : Icons.play_arrow,
          size: 20,
        ),
      ),
    );
  }
}
