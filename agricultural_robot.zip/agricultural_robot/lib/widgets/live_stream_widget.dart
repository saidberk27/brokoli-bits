import 'package:flutter/material.dart';
import 'mjpeg_stream.dart';

class LiveStreamWidget extends StatefulWidget {
  final String initialStreamUrl;

  const LiveStreamWidget({
    Key? key,
    required this.initialStreamUrl,
  }) : super(key: key);

  @override
  State<LiveStreamWidget> createState() => _LiveStreamWidgetState();
}

class _LiveStreamWidgetState extends State<LiveStreamWidget> {
  late TextEditingController _controller;
  late String _currentStreamUrl;

  @override
  void initState() {
    super.initState();
    _currentStreamUrl = widget.initialStreamUrl;
    _controller = TextEditingController(text: _currentStreamUrl);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _updateStreamUrl() {
    setState(() {
      _currentStreamUrl = _controller.text.trim();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12.0),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize:
              MainAxisSize.min, // Column'un minimum boyutta olmasını sağlar
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8.0),
              child: AspectRatio(
                aspectRatio: 4 / 3,
                child: MjpegStreamWidget(
                  streamUrl: _currentStreamUrl,
                  width: 640,
                  height: 480,
                ),
              ),
            ),
            const SizedBox(height: 12),
            LayoutBuilder(
              builder: (context, constraints) {
                return Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        width: constraints.maxWidth -
                            100, // Güncelle butonu için yer bırak
                        child: TextField(
                          controller: _controller,
                          decoration: const InputDecoration(
                            labelText: 'Kamera Akış Adresi',
                            border: OutlineInputBorder(),
                            isDense: true,
                            contentPadding: EdgeInsets.symmetric(
                                horizontal: 10, vertical: 8),
                          ),
                          style: const TextStyle(
                              fontSize: 14), // Yazı boyutunu küçült
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    SizedBox(
                      width: 85, // Sabit genişlik
                      child: ElevatedButton(
                        onPressed: _updateStreamUrl,
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 12,
                          ),
                        ),
                        child: const Text(
                          'Güncelle',
                          style: TextStyle(fontSize: 13),
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
