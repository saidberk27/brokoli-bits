import 'package:agricultural_robot/analysis_screen.dart';
import 'package:agricultural_robot/controls_screen.dart';
import 'package:agricultural_robot/home_screen.dart';
import 'package:flutter/material.dart';

class CustomBottomNavigationBar extends StatelessWidget {
  final int currentIndex;
  final Function(int) onTap;

  const CustomBottomNavigationBar({
    Key? key,
    required this.currentIndex,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: currentIndex,
      onTap: (index) {
        print(index);
        onTap(index);
        if (index == 0) {
          // Home tab
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => HomeScreen(
                toggleTheme: () {
                  // Theme toggle functionality will be handled by the HomeScreen
                },
              ),
            ),
          );
        } else if (index == 1) {
          // Analysis tab
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const AnalysisScreen()),
          );
        } else if (index == 2) {
          // Controls
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const ControlsScreen()),
          );
        }
      },
      type: BottomNavigationBarType.fixed,
      selectedItemColor: const Color(0xFF4CAF50),
      unselectedItemColor: Colors.grey,
      elevation: 8,
      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
        BottomNavigationBarItem(icon: Icon(Icons.bar_chart), label: "Analysis"),
        BottomNavigationBarItem(icon: Icon(Icons.tune), label: "Controls"),
      ],
    );
  }
}
